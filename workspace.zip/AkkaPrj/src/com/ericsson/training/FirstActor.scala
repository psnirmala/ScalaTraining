package com.ericsson.training

import akka.actor.Actor

class FirstActor extends Actor{
  def receive={
    case("hello")=>println("Good Morning")
    case("bye")=>println("Good Night")
    case(_)=>println("Ok")
  }
  
}