package com.ericsson.training

import akka.actor.ActorSystem
import akka.actor.Props

object ActorLaunch {
  def main(args: Array[String]): Unit = {
    val actorSystem=ActorSystem("TestActorSystem")
    val firstActor=actorSystem.actorOf(Props[FirstActor], "firstactor")
   // val secondActor=actorSystem.actorOf(Props[FirstActor], "firstactor")
    firstActor ! "hello"
    firstActor ! "bye"
    firstActor ! "Learn Scala"
    
    println("Going to shutdown the actor")
    actorSystem.shutdown()
    
    
  }
}