package client


import org.apache.http.impl.client.DefaultHttpClient
import org.apache.http.client.methods.HttpGet
import scala.collection.mutable._
import net.liftweb.json._


object RestTest {
   def getRestContent(url:String): String = {
    val httpClient = new DefaultHttpClient()
    val httpResponse = httpClient.execute(new HttpGet(url))
    val entity = httpResponse.getEntity()
    var content = ""
    if (entity != null) {
      val inputStream = entity.getContent()
      content = io.Source.fromInputStream(inputStream).getLines.mkString
      inputStream.close
    }
    httpClient.getConnectionManager().shutdown()
    return content
  }
   def main(args: Array[String]): Unit = {
     val content = getRestContent("http://localhost:9000/getStock")
     println(content)
     implicit val formats=DefaultFormats
     case class Stock(symbol:String,price:Double)
     val jvalue=parse(content)
     val stock=jvalue.extract[Stock]
     println(stock.symbol +" "+stock.price)
     
     
   }
}