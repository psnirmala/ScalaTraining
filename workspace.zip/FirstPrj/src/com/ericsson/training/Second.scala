package com.ericsson.training

object Second {

  def test(x: Int): Int =
    {
      x * x
    }


   def test1(x: Int): Int =
    {
      x * x * x
    }

  
  def sample(a: (Int) => Int, b: Int): Int =
    {
      val c = a(b)
      c + 10
    }
  
  
  def main(args: Array[String]): Unit = {

    println(sample(test, 4))
    println(sample(test1,3))
  }
}