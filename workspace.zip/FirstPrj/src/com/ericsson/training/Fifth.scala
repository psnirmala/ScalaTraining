package com.ericsson.training

object Fifth {
  def func1(x:Int):Int={
    x*2
  }
  
  //func2 is a function which takes two arguments. The first parameter f is a function
  //which takes an integer as argument and returns an integer.
  //The second argument g is an integer.
  //func2 returns a function which takes an integer as argument and returns another integer
  def func2(f:(Int)=>Int,g:Int):(Int)=>Int={
    val result1=f(g)
    x=>x*x+result1
  }
  
  def main(args: Array[String]): Unit = {
    val result=func2(func1,10)(5)
    println(result)
    val nextResult=func2(x=>x/2,20)(4)
    println(nextResult)
  }
}