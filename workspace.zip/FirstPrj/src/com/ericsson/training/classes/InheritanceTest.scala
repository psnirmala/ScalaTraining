package com.ericsson.training.classes

object A{
    val i=10
    
    def test()
    {
      println("This is a static method")
    }
}

object InheritanceTest {
  def main(args: Array[String]): Unit = {
    val c1=new Customer("Rakesh","Male",24,1001,8000)
    println(c1)
    println(c1.isInstanceOf[Customer])
    println(c1.isInstanceOf[Person])
    println(c1.isInstanceOf[AnyRef])
    println(A.i)
    A.test()
  }
}