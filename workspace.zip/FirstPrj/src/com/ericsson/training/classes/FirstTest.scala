package com.ericsson.training.classes

class Address(val location:String,val city:String)
{
  def print()
  {
    println(location+"\t"+city)
  }
}

class Employee(val id:Int,val name:String){
   var designation:String=null
   var address:Address=null
   
def  this(id:Int,name:String,designation:String)
  {
    this(id,name)
    this.designation=designation
  }
   def  this(id:Int,name:String,designation:String,address:Address)
  {
    this(id,name)
    this.designation=designation
    this.address=address
  }
  def print()
  {
    var s="";
    if(designation!=null){
       s=designation
    }
  
    println(id+"\t"+name+"\t"+s)
    if(address!=null){
      address.print()
    }
  }
}

object FirstTest {
  def main(args: Array[String]): Unit = {
    /*val e1=new Employee(1001,"Rajesh")
    val e2=new Employee(1002,"Akash")
    println(e1.id)
    e1.print()
    e2.print()
    val e3=new Employee(1003,"Ramesh","Developer")
    e3.print()*/
    val e4=new Employee(5001,"Deva","Accountant",new Address("KRPuram","Bangalore"))
    e4.print()
  }
}