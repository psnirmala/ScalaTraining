package com.ericsson.training.classes

class Person(name:String,gender:String,age:Int)
{
  override def toString():String=
  {
    "Name: "+name+"\tGender:"+gender+"\tAge:"+age
  }
}

class Customer(name:String,gender:String,age:Int,id:Int,balance:Double)
extends Person(name,gender,age){
  override def toString():String=
  {
     super.toString()+"\tID:"+id+"\tBalance: "+balance
  }
  
}