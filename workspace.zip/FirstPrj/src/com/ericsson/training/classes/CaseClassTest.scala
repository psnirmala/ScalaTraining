package com.ericsson.training.classes

case class Product(id:Int,name:String,price:Double){
  def print()
  {
    println(id+"\t"+name+"\t"+price)
  }
}

object CaseClassTest {
  def main(args: Array[String]): Unit = {
    val p1=Product(101,"Titan 21F model",1500);
    val p2=Product(102,"Sonata 3e model",1200);
    
    p1.print()
    p2.print()
    
    val array=Array(Array(12,"Product1",120.34),Array(13,"Product2",34.64))
    array.map(prdt=>Product(prdt(0).toString.toInt,prdt(1).toString(),
        prdt(2).toString.toDouble)).
        foreach(prdt=>prdt.print())
    
  }
}