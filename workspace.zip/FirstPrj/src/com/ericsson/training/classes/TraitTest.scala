package com.ericsson.training.classes
trait Flyer{
  def fly()
}
trait Feedable{
  def eat()
}

class Animal{
  
}
class Bird extends   Flyer with Feedable{
  def fly()
  {
    println("flying")
  }
  def eat()
  {
    println("eating")
  }
}

object TraitTest {
  def main(args: Array[String]): Unit = {
    val b=new Bird();
    b.fly();
    b.eat()
    println(b.isInstanceOf[Flyer])
    println(b.isInstanceOf[Feedable])
    println(b.isInstanceOf[Animal])
  }
}