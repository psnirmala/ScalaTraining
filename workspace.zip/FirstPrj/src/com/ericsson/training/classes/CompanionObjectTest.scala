package com.ericsson.training.classes

class X{
  protected val  i=10
  val j=20
  }
object X{
  def test(x1:X):Unit=
  {
    println(x1.i)
  }
  
}

class Y extends X{
  def test()
  {
    println(i)
  }
}


object CompanionObjectTest {
  def main(args: Array[String]): Unit = {
    X.test(new X())
    val x=new X()
    println(x.j)
    //println(x.i)
  }
}