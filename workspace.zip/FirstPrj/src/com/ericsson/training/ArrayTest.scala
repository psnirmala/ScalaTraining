package com.ericsson.training

object ArrayTest {
  def main(args: Array[String]): Unit = {
    val array=new Array[String](5)
    array(0)="apple"
    array(1)="orange"
    array(2)="grape"
    array(3)="mango"
    array(4)="pine apple"

    /*val array=Array(34,55,34,76,"ddd")*/
    for(i<-0 to array.length-1){
      println(array(i))
    }
    println("using for each");
    array.foreach(println)
     println("using for each without shortcut");
    
    array.foreach(element=>println(element.length()))
      println("using for each with _");
    array.foreach(println(_))
    
  }
}