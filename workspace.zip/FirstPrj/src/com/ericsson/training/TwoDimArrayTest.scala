package com.ericsson.training

object TwoDimArrayTest {
  def main(args: Array[String]): Unit = {
    val array=Array.ofDim[Int](2,3);
    array.foreach(x=>{
      println();
      x.foreach(a=>print(a+"\t"))
    })
    val array1=Array(Array(3,2,5),Array(12,45),Array(5,33,22,12))
    array1.foreach(x=>{
      println();
      x.foreach(a=>print(a+"\t"))
    })
  }
}