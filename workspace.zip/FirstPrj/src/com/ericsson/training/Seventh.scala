package com.ericsson.training

object Seventh {
  def square(x:Int):Int=
  {
    x*x
  }
  
  
  def test(f:(Int)=>Int,x:Int,y:Int):Int=
  {
    f(x)+f(y)
  }
  
  def main(args: Array[String]): Unit = {
  val sq=square(10)
  println(sq)
  
  println(test(square,5,3))
  
  def t=square(_:Int)*10; //is equivalent to def t=(a:Int)=>square(a)*10
  println(t(10))
  
  def y=test(x=>x*3,_:Int,_:Int)  // is equivalent to y=(a:Int)=>test(x=>x*3,a)
  println(y(20,5))
  
  /*val list=List(4,2,5)
  
  list.map(x=>x*2).foreach(println)
  list.map(_*2).foreach(println)
  
  println(list.reduce((x,y)=>x+y))
  println(list.reduce(_+_))*/
  
  def a=square(_:Int)+3
  println(a(5))

  }
  
}