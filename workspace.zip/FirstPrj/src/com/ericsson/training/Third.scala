package com.ericsson.training

object Third {
 /* def func1(x:Int,y:Int):Int=
  {
    x*y
  }
  
  def func2(x:Int):Int=
  {
    x+2
  }*/
  
  def func3(f1:(Int)=>Int,f2:(Int,Int)=>Int,x:Int,y:Int,z:Int):Int=
  {
    val result1=f1(x)
    val result2=f2(y,z)
    result1+result2
  }
  
  
  def main(args: Array[String]): Unit = {
    var result=func3(a=>
      {a*a},
      (b,c)=>{
        b*c
      },
      
      10,2,5)
    println(result)
    result=func3(a=>a+5,(b,c)=>b-c,10,25,5)
    println(result)
    def func4=(f:(Int)=>Int)=>f(10)+5
    val y=func4(x=>x*2)
    println(y)
    
    
  }
}