package com.ericsson.training

object First {
  def add(x:Int,y:Int):Int={
     x+y
  }
  def test(){
    println("This is a test function")
  }
  
  def main(args: Array[String]): Unit = {
    println(add(10,20))
    
   def subtract=(x:Int,y:Int)=>x-y
   
    println(subtract(20,4))
    test()
    
  }
}