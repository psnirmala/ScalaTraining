package com.ericsson.training

object Sixth {
 
  
  def main(args: Array[String]): Unit = {
  def totalPrice=(actualPrice:Int,discount:Double)=>(1-discount/100)*actualPrice
 // def discountApplied=(x:Int)=>totalPrice(x,20)
  
  
  
 def discountApplied=totalPrice(_:Int,20)
  val result1=discountApplied(200)
  val result2=discountApplied(100)
  println(result1)
  println(result2)
  
  
  
  }
}