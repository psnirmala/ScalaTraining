package com.ericsson.training

object Fourth {
  
  def test(x:String):(Int)=>String={
    val y=x.length()
    println(y)
    (t:Int)=>t+" hello"
    
  }
  
  def next():()=>Unit={
    println("within next before returning a function")
    ()=>{
      println("this is the returned function")
    }
  }
  def main(args: Array[String]): Unit = {
    val result=test("this is a test")(20)
    println(result)
    
    
    val result1=test("this is a test")
    val result2=result1(20)
    println(result2)
    
    next()()
  }
}