package controllers

import play.api.mvc.Controller
import play.api.mvc.Action


object MyController extends Controller{
  
  def next=Action{
    Ok(views.html.second("Rajesh","Developer"))
  }
  
}