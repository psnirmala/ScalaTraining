package controllers

import play.api.mvc.Controller
import play.api.mvc.Action
import models.Employee
import com.typesafe.config.ConfigFactory

object EmployeeController extends Controller {
  
  def details=Action{
    val e=Employee(101,"Rakesh","Accountant")
    println(ConfigFactory.load().getString("application.langs"))
    Ok(views.html.empDetails(e))
  }
  
}