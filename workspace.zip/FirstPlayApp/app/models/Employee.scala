package models

case class Employee(id:Int,name:String,designation:String) {
  
}