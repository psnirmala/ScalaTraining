package com.ericsson.training.oops

object TupleTest extends App {
  val tuple1=(23,54,"Hello")
  println(tuple1._1)
  println(tuple1._2)
  println(tuple1._3)
  tuple1.productIterator.foreach(println)
  
}