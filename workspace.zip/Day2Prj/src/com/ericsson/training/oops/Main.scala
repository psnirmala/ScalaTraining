package com.ericsson.training.classes

object Main extends App {
  println("This is a test without main method")
  
}