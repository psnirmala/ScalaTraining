package com.ericsson.training.oops

class X{
  override def toString():String={
    "Object of type X"
  }
}

class Y{
  def apply():X={
    new X()
  }
}

class Customer(id:Int,name:String,balance:Double){
   
  override def toString():String={
    id+"\t"+name+"\t"+balance
  }
}
object Customer{
  def apply(a:Int,b:String,c:Double):Customer={
    new Customer(a,b,c)
  }
}

object ApplyTest  extends App{
  val y1=new Y()
  val x1=y1()
  println(x1)
  val c1=Customer(101,"Deva",9000)
  println(c1)
  
  
}