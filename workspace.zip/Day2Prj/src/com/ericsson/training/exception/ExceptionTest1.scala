package com.ericsson.training.exception

import scala.io.BufferedSource
import scala.io.Source
import java.io.FileNotFoundException

object ExceptionTest1 {
  def main(args: Array[String]): Unit = {
    var source:BufferedSource=null
   try{
      source=Source.fromFile("x.txt")
      source.getLines().foreach(println)
   }catch{
     case(ex1:FileNotFoundException)=>println("No such file ")
   }finally{
     if(source!=null){
       source.close()
     }
   }
  }
}