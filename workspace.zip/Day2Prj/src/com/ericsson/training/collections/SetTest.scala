package com.ericsson.training.collections

import scala.collection._

object SetTest {
  def main(args: Array[String]): Unit = {
    val set1=Set(34,55,87)
    //set1+=56
    set1.foreach(println)
    val set2=mutable.Set("apple","orange","pine apple","apple")
    set2+="orange"
    set2+="grape"
    set2.foreach(println)
  }
}