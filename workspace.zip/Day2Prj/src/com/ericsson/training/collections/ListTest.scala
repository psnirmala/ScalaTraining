package com.ericsson.training.collections

import scala.collection.mutable.MutableList



object ListTest {
  def main(args: Array[String]): Unit = {
    val list=List(23,55,34,40)
    list.foreach(println)
    val list1=MutableList(34,55,23)
    list1 += 45
    list1+=67
    list1.foreach(println)
    list1 foreach println
    
    list1.foreach {
      println
    }
  }
}