package com.ericsson.training.collections

object MapReduceTest {
  def main(args: Array[String]): Unit = {
    val list=List(3,5,8)
    val value=list.map(x=>x*x).reduce((x,y)=>x+y)
    println("value :"+value)
    
   val myVal= list.map(x=>x*x).reduce(_+_)
   println(myVal)
   val list1=List("dddd","rrrrr")
   val nextVal=list1.reduce(_+" "+_)// reduce((x,y)=>x+" "+y
   println(nextVal)
   
   val a=Array(Array(3,5,6,3),Array(2,5),Array(5,3,2))
  val p=a.flatMap(x=>x).map(x=>x*x).reduce((x,y)=>x+y)
  println(p)
   
  }
}