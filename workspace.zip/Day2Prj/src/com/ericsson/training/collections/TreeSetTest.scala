package com.ericsson.training.collections

import scala.collection.mutable.TreeSet


class MyOrdering extends Ordering[Pair]{
  def compare( p1:Pair, p2:Pair):Int=
    
  {
    (p1.first+p1.second).compareTo(p2.first+p2.second)
  }
     }

object TreeSetTest {
  def main(args: Array[String]): Unit = {
  /*  val set=new TreeSet[Pair]()((p1,p2)=>{
      (p1.first+p1.second).compareTo(p2.first+p2.second)
    })*/
    
    val set=new TreeSet[Pair]()(new MyOrdering())
    set+=new Pair(12,44)
    set+=new Pair(3,34)
    set+=new Pair(23,55)
    set+=new Pair(14,80)
    set.foreach(println)
    
  }
}