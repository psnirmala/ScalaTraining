package com.ericsson.training.collections

import scala.collection.mutable.Set

class Person(val firstName:String,val lastName:String,val age:Int)  {
  override def toString():String={
    "First Name: "+firstName+" Last Name: "+lastName+" Age: "+age
  }
  override def equals(obj:Any):Boolean={
    println("invoking equals of "+firstName)
    var eq=false
    val p=obj.asInstanceOf[Person]
    if(firstName==p.firstName && lastName==p.lastName&&age==p.age){
      eq=true
    }
    eq
  }
  override def hashCode():Int={
    println("invoking hashCode of "+firstName)
    firstName.hashCode()
  }
}

object UserDefinedElementSet {
  def main(args: Array[String]): Unit = {
    val set=Set(new Person("Joseph","Miller",34), new Person("Miller","Joseph",78))
    set+=new Person("Joseph","Miller",34)
    set+=new Person("Miller","Joseph",78)
    set+=new Person("Joseph","Reno",34)
    set.foreach(println)
  }
  
}