package com.ericsson.training.collections

class Emp(id:Int,name:String,designation:Option[String])
{
  def print()
  {
    println(id+"\t"+name)
    if(!designation.isEmpty){
      println(designation.get)
    }
  }
}

object OptionTest {
  def main(args: Array[String]): Unit = {
    val e1=new Emp(23,"Rakesh",None)
    val e2=new Emp(34,"Amar",Some("Developer"))
    e1.print()
    e2.print()
  }
}