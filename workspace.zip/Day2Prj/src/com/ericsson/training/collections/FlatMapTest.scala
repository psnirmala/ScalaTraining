package com.ericsson.training.collections

import scala.collection.mutable.MutableList

object FlatMapTest {
  def main(args: Array[String]): Unit = {
    val list=MutableList[String]()
    list += "the cat sat on the mat"
    list+="the aardvak sat on the table"
    //println(list)
    list.flatMap(l=>l.split(" ")).map(a=>a.toUpperCase()).foreach(println)
    println("using under score")
    list.flatMap(_.split(" ")).map(_.toUpperCase()).foreach(println)
  }
}