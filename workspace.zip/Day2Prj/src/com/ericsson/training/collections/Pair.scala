package com.ericsson.training.collections

class Pair(val first:Int,val second:Int) extends Ordered[Pair]{
def compare(element:Pair):Int={
    if(first < element.first){
       -1;
    }
    else if(first >  element.first){
       1
    }
    else{
      0
    }
  }
  override def toString():String={
    "first: "+first+"\tsecond: "+second
  }
}
