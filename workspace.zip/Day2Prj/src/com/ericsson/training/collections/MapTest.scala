package com.ericsson.training.collections

import scala.collection.immutable.Map

object MapTest {
  def main(args: Array[String]): Unit = {
    val map=Map("a"->3344,"b"->5444,"c"->6444)
    map.keys.foreach(key=>{
      println(key+"=="+map(key))
    })
    
    val list=map.values
    list.foreach(println)
    println(map.contains("a"))
  }
}