package com.ericsson.training.collections

object MapFunctionTest {
  def main(args: Array[String]): Unit = {
    val list=List(3,5,7,10)
   /* list.map(x=>x*2).map(x=>x*x).foreach(println)
    list.map(multiplyByTwo).map(square).foreach(println)*/
    list.filter(x=>x>5).map(x=>x*2).map(x=>x*x).foreach(println)
    
    list.filter(_>5).map(_*2).map(x=>x*x).foreach(println)
    
  }
  
  def multiplyByTwo(n:Int):Int=n*2
  def square(n:Int):Int=n*n
  
}