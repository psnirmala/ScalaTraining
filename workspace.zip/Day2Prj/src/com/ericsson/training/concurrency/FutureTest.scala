package com.ericsson.training.concurrency

import scala.concurrent.ExecutionContext.Implicits.global //provides the thread pool for future object
import scala.concurrent.Future
import scala.util.Failure
import scala.util.Success

object FutureTest {
  def main(args: Array[String]): Unit = {
    println("Going to launch the thread");
    val future=Future{ 
          for(i<-1 to 100){
            Thread.sleep(10)
            
          }
    }
    future.onComplete({
      case Success(value)=>println("value received: "+value)
      case Failure(e)=>println("Exception message: "+e.getMessage)
    })
    println("First")
    Thread.sleep(100)
     println("Second")
    Thread.sleep(200)
    println("Third")
    Thread.sleep(300)
    
    println("Fourth")
    Thread.sleep(400)
  }
}