package controllers

import models.Task
import play.api.mvc._
import com.typesafe.config.ConfigFactory


object TaskController extends Controller {

  def index = Action {
     
    Redirect(routes.TaskController.tasks)
  }

  def tasks = Action {
    val companyName=ConfigFactory.load().getString("companyName")
    Ok(views.html.index(Task.all,companyName))
  }

  def newTask = Action(parse.urlFormEncoded) {
    implicit request =>
      {
       println(request.body.get("taskName"))
       println(request.body.get("taskName").get)
         println(request.body.get("taskName").get.head)
      Task.add(request.body.get("taskName").get.head)
      }
      Redirect(routes.TaskController.index)
  }

  def deleteTask(id: Int) = Action {
    Task.delete(id)
    Ok
  }

}
